#!/bin/bash
set -e

# ANDROID_NDK_ROOT and ANDROID_SDK_ROOT need to be set (possibly to ~/Android/Sdk/ndk/##.#.#######/ and ~/Android/Sdk respectively)

export ANDROID_NDK_ROOT=/usr/local/android-ndk
export ANDROID_SDK_ROOT=/usr/local/android-sdk

VERSION=7.0.3
OUT_DIRECTORY=ffmpeg-android-$VERSION-aarch64

if [ ! -d "ffmpeg-kit" ]; then
    tar xf ffmpeg-kit.tar.xz
fi

cd ffmpeg-kit

./android.sh \
    --enable-gpl \
    --enable-x264 \
    --enable-libvpx \
    --enable-android-media-codec \
    --disable-arm-v7a-neon \
    --disable-arm-v7a \
    --disable-x86-64 \
    --disable-x86 \
    --no-archive

cd ..

mkdir $OUT_DIRECTORY

cp $0 $OUT_DIRECTORY
cp -r ffmpeg-kit/prebuilt/android-arm64/{ffmpeg,libvpx,x264}/* $OUT_DIRECTORY/
cp ffmpeg-kit/src/ffmpeg/config.h ffmpeg-kit/src/ffmpeg/libavcodec/codec_internal.h $OUT_DIRECTORY/include/libavcodec/

tar c $OUT_DIRECTORY | xz -T0 > $OUT_DIRECTORY.tar.xz

